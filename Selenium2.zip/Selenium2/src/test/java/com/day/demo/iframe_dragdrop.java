package com.day.demo;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class iframe_dragdrop {
	public static class Demo1 {
		public static void main(String[] args) throws InterruptedException {
			WebDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			driver.get("https://jqueryui.com/droppable/");
			driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[class='demo-frame']")));
			Actions a=new Actions(driver);
			
		WebElement	drag=driver.findElement(By.id("draggable"));
		
		WebElement	drop=driver.findElement(By.id("droppable"));
	
			
			a.dragAndDrop(drag, drop).build().perform();
			Thread.sleep(3000);
			driver.switchTo().defaultContent();
			

		}
	}
}
