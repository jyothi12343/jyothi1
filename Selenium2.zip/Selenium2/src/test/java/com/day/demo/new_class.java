package com.day.demo;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class new_class {
    public static class Demo1 {
        public static void main(String[] args) throws InterruptedException {

            // Setup WebDriver
            WebDriver driver = new ChromeDriver();
            driver.manage().window().maximize();
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

            // Open the webpage
            driver.get("https://www.tutorialspoint.com/selenium/practice/resizable.php");

            // Locate the resizable handle element (bottom-right corner)
            WebElement drag = driver.findElement(By.xpath("//div[contains(@class, 'ui-resizable-handle ui-resizable-se')]"));

            // Initialize Actions class
            Actions a = new Actions(driver);

            // Resize the element by dragging the handle (e.g., 50 pixels to the right and 90 pixels down)
            a.clickAndHold(drag).moveByOffset(50, 90).release().perform();

            // Add a small delay to observe the change
            Thread.sleep(5000);

            // Close the browser
            driver.quit();
        }
    }
}
