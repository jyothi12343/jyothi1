package com.day.demo;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo {

    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

        driver.get("https://rahulshettyacademy.com/locatorspractice/");

        // Login
        /*
         * driver.findElement(By.id("inputUsername")).sendKeys("rahul");
        driver.findElement(By.name("inputPassword")).sendKeys("jyothi");
        driver.findElement(By.className("submit")).click();

        // Print error message
        System.out.println(driver.findElement(By.cssSelector("p.error")).getText());

        // Forgot password
        driver.findElement(By.linkText("Forgot your password?")).click();
        Thread.sleep(1000);

        // Reset password form
        driver.findElement(By.cssSelector("input[type='text']")).sendKeys("rahul11");
        driver.findElement(By.xpath("//form/input[3]")).sendKeys("6360917834");
        Thread.sleep(3000);

        // Click reset password button
        driver.findElement(By.className("reset-pwd-btn")).click();
        System.out.println(driver.findElement(By.cssSelector("form p")).getText());*/

        // Close the browser
        driver.quit();
        
       // login in to page
        
        driver.findElement(By.id("inputUsername")).sendKeys("rahul");
        Thread.sleep(3000);
        driver.findElement(By.name("inputPassword")).sendKeys("rahulshettyacademy");
        Thread.sleep(3000);
        driver.findElement(By.className("submit")).click();
        Thread.sleep(3000);
    }
}
