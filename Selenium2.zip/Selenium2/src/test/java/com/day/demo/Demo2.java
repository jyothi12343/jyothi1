package com.day.demo;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo2 {
	public static class Demo1 {
		public static void main(String[] args) {
			WebDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			driver.get("https://demo.automationtesting.in/Register.html");
			driver.findElement(By.cssSelector(".dropdown-toggle")).click();
			driver.findElement(By.xpath("//a[text()='Windows']")).click();
			driver.findElement(By.xpath("//button[text()='    click   ']")).click();

			Set<String> window = driver.getWindowHandles();
			Iterator<String> it = window.iterator();
			String parentId = it.next();
			String childId = it.next();
			String childID1 = it.next();
			driver.switchTo().window(childId);
			System.out.println(driver.findElement(By.className("h3")).getText());
			driver.switchTo().window(parentId);
			driver.findElement(By.xpath("//a[text()='Open New Seperate Windows']")).click();
			driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
			driver.switchTo().window(childID1);
			System.out.println(driver.findElement(By.xpath("//h4[@class='h3 mb-3 selenium-ide']")).getText());
		}
	}
}
