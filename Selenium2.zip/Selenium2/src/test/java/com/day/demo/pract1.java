package com.day.demo;

import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.awt.Desktop.Action;
import java.io.File;
import java.io.IOException;
import java.lang.classfile.WritableElement;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.common.io.Files;

public class pract1 {
	public static class Demo1 {
		public static void main(String[] args) throws InterruptedException, IOException 
		
		
		{
		
			
			WebDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

			driver.get("https://www.tutorialspoint.com/selenium/practice/text-box.php");
			/*
			 * driver.findElement(By.id("fullname")).sendKeys("jyothi");
			 * driver.findElement(By.id("email")).sendKeys("jyothi@gmail.com");
			 * driver.findElement(By.id("address")).sendKeys("hebbal,cholanayakanahalli");
			 * driver.findElement(By.id("password")).sendKeys("jyothi123");
			 * driver.findElement(By.className("btn")).click();
			 * driver.findElement(By.className("accordion-button")).click();
			 * 
			 * // checkbox driver.findElement(By.xpath("//div/ul/li[2]")).click();
			 * driver.findElement(By.xpath("//span[@class='plus'][1]")).click();
			 * driver.findElement(By.xpath("//span[@class='plus'][1]")).click();
			 * 
			 * List<WebElement> checkbox =
			 * driver.findElements(By.xpath("//input[@type='checkbox']"));
			 * 
			 * for (WebElement check : checkbox) {
			 * 
			 * check.click(); // WebElement label =
			 * check.findElement(By.xpath("./following-sibling::label")); //
			 * System.out.println(label.getText());
			 * 
			 * // HOW TO GET TEXT FOR CHECKED CHECKBOX }
			 * 
			 * Thread.sleep(3000); //
			 * driver.findElement(By.xpath("//span[@class='plus'][1]")).click();
			 * 
			 * 
			 * // RADIO BUTTON
			 * 
			 * driver.findElement(By.xpath("//div/ul/li[3]")).click();
			 * 
			 * List<WebElement> radioButtons =
			 * driver.findElements(By.xpath("//input[@type='radio']"));
			 * 
			 * for (WebElement radioButton : radioButtons) { String value =
			 * radioButton.getAttribute("value");
			 * 
			 * // Check if the value is "Impressive" if
			 * (value.equalsIgnoreCase("Impressive")) { radioButton.click();
			 * 
			 * 
			 * driver.findElement(By.xpath("//div/ul/li[4]")).click();
			 * driver.findElement(By.xpath("(//a[@class='edit-wrap'])[1]")).click();
			 * 
			 * WebElement inputField = driver.findElement(By.id("firstname"));
			 * inputField.clear();inputField.sendKeys("jyothi");
			 * 
			 * driver.findElement(By.xpath("(//input[@type='submit'])[1]")).click();
			 * 
			 * 
			 * 
			 * Actions a = new Actions(driver);
			 * 
			 * driver.findElement(By.xpath("//div/ul/li[5]")).click();
			 * driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
			 * 
			 * WebElement
			 * doubleclick=driver.findElement(By.xpath("//button[@class='btn btn-success']")
			 * ); a.doubleClick(doubleclick).build().perform();
			 * 
			
			driver.findElement(By.xpath("//div/ul/li[6]")).click();
			System.out.println(driver.findElements(By.tagName("a")).size());

			driver.findElement(By.xpath("//a[text()='Home']")).click();
			System.out.println(driver.findElement(By.xpath("//div/h1")).getText());
			Set<String> windows = driver.getWindowHandles();
			Iterator<String> it = windows.iterator();
			String parentId = it.next();
			String childId = it.next();
			driver.switchTo().window(parentId);
			driver.findElement(By.xpath("//a[text()='HomewPWPU']")).click();
			driver.findElement(By.id("created")).click();
	String	actual=	driver.findElement(By.xpath("//div[@class='create']")).getText();
	String expected="Link has responded with staus 201 and status text Created";
	Assert.assertEquals(actual, expected);
			

			// List<WebElement> links=driver.findElements(By.className("text-left"));
			 
			 */

			driver.findElement(By.xpath("//div/ul/li[7]")).click();
			driver.findElement(By.xpath("//a[text()='Click Here for Broken Link']")).click();
			System.out.println(driver.findElement(By.xpath("//div[@class='container bg-white p-4 text-center mt-5 rounded']")).getText());
			driver.navigate().back();
			
			driver.findElement(By.xpath("//div/ul/li[8]")).click();
			driver.findElement(By.id("downloadButton")).click();
			
			driver.findElement(By.xpath("//div/ul/li[9]")).click();
			driver.findElement(By.id("colorChange")).click();
			System.out.println(driver.findElement(By.xpath("//button[text()='Visible After 5 Seconds']")).getText());
			Thread.sleep(6000);
			
			
			

		}

		
		}

	}

