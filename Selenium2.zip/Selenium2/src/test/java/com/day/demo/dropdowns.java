package com.day.demo;

import java.awt.Desktop.Action;
import java.io.File;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.google.common.io.Files;

public class dropdowns {
	public static class Demo1 {
		public static void main(String[] args) throws InterruptedException {
			WebDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			driver.get("https://rahulshettyacademy.com/dropdownsPractise/");

			WebElement dropdowns = driver.findElement(By.id("ctl00_mainContent_DropDownListCurrency"));
			Select select = new Select(dropdowns);
			// select.selectByVisibleText("AED");
			// select.selectByIndex(0);
			select.selectByValue("INR");
			Thread.sleep(5000);

			driver.findElement(By.id("divpaxinfo")).click();
			int i = 1;
			while (i < 5) {
				driver.findElement(By.id("hrefIncAdt")).click();
				i++;
			}
			driver.findElement(By.id("btnclosepaxoption")).click();

			// dynamic dropdowns

			driver.findElement(By.id("ctl00_mainContent_ddl_originStation1_CTXT")).click();
			driver.findElement(By.xpath("//a[@value='BLR']")).click();
			driver.findElement(By.xpath("//a[@value='DEL']")).click();
			Thread.sleep(5000);

			// auto suggest dropdown
			driver.findElement(By.id("autosuggest")).sendKeys("ind");

			List<WebElement> options = driver.findElements(By.cssSelector("li[class='ui-menu-item'] a"));
			
			for(WebElement option : options)
			{
				
				if(option.getText().equalsIgnoreCase("India"))
				{
				option.click();
				break;
			}
			Thread.sleep(9000);
			
			
			//checkbox
			driver.findElement(By.cssSelector("input[id='ctl00_mainContent_chk_friendsandfamily']")).isSelected();
			System.out.println(driver.findElement(By.xpath("input[type='checkbox']")).getSize());
			
			File f=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		   //    Files.copy(f, new File("/Users/jyothi.n/Downloads/screenshot//amazon.png"));

			driver.quit();

		}
	}
}
}